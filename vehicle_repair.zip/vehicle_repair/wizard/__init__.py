# -*- coding: utf-8 -*-
from . import vehicle_repair_wizard
