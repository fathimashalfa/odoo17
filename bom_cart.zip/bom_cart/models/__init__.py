# -*- coding: utf-8 -*-

from . import res_config_settings
