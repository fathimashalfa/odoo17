# -*- coding: utf-8 -*-

from . import vehicle_repair
from . import repair_tag
from . import res_partner
